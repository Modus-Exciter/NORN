use postgres::{Client, NoTls, Error};
use chrono::{Utc, Duration};
use rand::Rng;
use rand::seq::SliceRandom;
use eframe::egui;

const DATABASE_URL: &str = "postgresql://journaluser:JENf25ftgybhnjkef@10.8.8.8/journal";

fn create_db_client() -> Result<Client, Error> {
    Client::connect(DATABASE_URL, NoTls)
}

fn create_table() -> Result<(), Error> {
    let mut client = create_db_client()?;

    client.batch_execute("
        CREATE TABLE IF NOT EXISTS journal (
            id              SERIAL PRIMARY KEY,
            processid       VARCHAR NOT NULL,
            starttime       bigint NOT NULL,
            endtime         bigint NOT NULL,
            username        VARCHAR NOT NULL,
            params          VARCHAR NOT NULL
        );
    ")?;

    Ok(())
}

// fn insert_in_db(
//     process_id: &str,
//     start_time: &str,
//     end_time: &str,
//     user: &str,
//     params: &str,
// ) -> Result<(), Error> {
//     create_table();
//     let mut client = create_db_client()?;

//     client.execute(
//         "INSERT INTO journal (processid, starttime, endtime, username, params) VALUES ($1, $2, $3, $4, $5)",
//         &[&process_id, &start_time, &end_time, &user, &params],
//     )?;

//     Ok(())
// }

fn insert_in_db(data: DataType) -> Result<(), Error> {
    create_table();
    let mut client = create_db_client()?;

    client.execute(
        "INSERT INTO journal (processid, starttime, endtime, username, params) VALUES ($1, $2, $3, $4, $5)",
        &[&data.process_id, &data.start_time, &data.end_time, &data.user, &data.params],
    )?;

    Ok(())
}

#[derive(Debug)]
struct DataType {
    _id: i32,
    process_id: String,
    start_time: i64,
    end_time: i64,
    user: String,
    params: String,
}

fn select_for_user(user: &str) -> Result<DataType, Box<dyn std::error::Error>> {
    let mut client = create_db_client()?;

    let rows = client.query("SELECT * FROM journal WHERE username=$1", &[&user])?;

    let row = rows.first().ok_or("No rows returned")?;

    let respdata = DataType {
        _id: row.get(0),
        process_id: row.get(1),
        start_time: row.get(2),
        end_time: row.get(3),
        user: row.get(4),
        params: row.get(5),
    };

    Ok(respdata)
}

fn fetch_data(offset: i8) -> Result<Vec<DataType>, postgres::Error> {
    let mut client = create_db_client()?;
    let mut page = offset * 20;
    let page_i32: i64 = page.into();
    let mut data = Vec::new();
    for row in client.query("SELECT * FROM journal LIMIT 20 OFFSET $1", &[&page_i32])? {
        let record = DataType { 
            _id: row.get(0), 
            process_id: row.get(1), 
            start_time: row.get(2),
            end_time: row.get(3),
            user: row.get(4),
            params: row.get(5),
        };
        data.push(record);
    }

    Ok(data)
}

fn generate_userprocess() -> DataType {
    let process: String = "function.dll".to_string();

    let mut rng = rand::thread_rng();
    let params = format!("-f {} -g {}", rng.gen_range(0..100), rng.gen_range(0..100));

    let starttime = (Utc::now() + Duration::seconds(rng.gen_range(0..1001))).timestamp();
    let endtime = (Utc::now() + Duration::seconds(rng.gen_range(0..1001))).timestamp();

    let letters: Vec<char> = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        .chars()
        .collect();
    let user: String = (0..5)
        .map(|_| *letters.choose(&mut rng).unwrap())
        .collect();
    let respdata = DataType {
        _id: 0,
        process_id: process,
        start_time: starttime,
        end_time: endtime,
        user: user,
        params: params,
    };

    respdata
}


struct WindowApp {
    process: String,
    params: String,
    update: bool,
    page: i8,
    iteratorupdate: i32,
    buffer: Vec<DataType>,
}

impl WindowApp {
    fn new(_cc: &eframe::CreationContext<'_>) -> Self {
        WindowApp {
            process: String::new(),
            params: String::new(),
            update: true,
            page: 0,
            iteratorupdate: 0,
            buffer: Vec::new(),
        }
    }
}

impl eframe::App for WindowApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        egui::CentralPanel::default().show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label("Process Name: ");
                ui.text_edit_singleline(&mut self.process);
                ui.label("Params: ");
                ui.text_edit_singleline(&mut self.params);
                if ui.button("Start").clicked() {
                    // Запускаем выполнение операции
                }
            });

                egui::Grid::new("keyboard")
                .num_columns(6)
                .max_col_width(120.0)
                .show(ui, |ui| {
                    if self.update == true {
                        println!("{}", self.page.to_string());
                        match fetch_data(self.page) {
                            Ok(data) => {  
                                self.buffer = data;  // `data` теперь является вектором записей
                                self.update = false;
                                // self.iteratorupdate = self.iteratorupdate + 1;
                                // if self.iteratorupdate == 3{
                                //     self.update = false;
                                //     self.iteratorupdate = 0;
                                // }
                            },
                            Err(err) => {
                                eprintln!("Error: {}", err);
                            }
                        }
                    }
                    for record in &self.buffer {
                        ui.with_layout(egui::Layout::top_down_justified(egui::Align::Center), |ui| {
                                let _ = ui.heading(record.process_id.clone());
                        });
        
                        ui.with_layout(egui::Layout::top_down_justified(egui::Align::Center), |ui| {
                                let _ = ui.heading(record.params.clone());
                        });
                        ui.with_layout(egui::Layout::top_down_justified(egui::Align::Center), |ui| {
                                let _ = ui.heading(record.start_time.to_string().clone());
                        });
        
                        ui.with_layout(egui::Layout::top_down_justified(egui::Align::Center), |ui| {
                                let _ = ui.heading(record.end_time.to_string().clone());
                        });
        
                        ui.with_layout(egui::Layout::top_down_justified(egui::Align::Center), |ui| {
                                let _ = ui.heading(record.user.clone());
                        });
        
                        ui.with_layout(egui::Layout::top_down_justified(egui::Align::Center), |ui| {
                        if ui.button("Copy").clicked() {
                            self.process = String::from(record.process_id.clone());
                            self.params = String::from(record.params.clone());
                        }
                    });
                        ui.end_row();
                    }
                    
                    // Кнопки переключения страниц


                ui.with_layout(egui::Layout::top_down_justified(egui::Align::Center), |ui| {
                if ui.button("<--").clicked() {
                    self.update = true;
                    if self.page > 0 {
                        self.page = self.page - 1;
                    }
                }
            });

            ui.with_layout(egui::Layout::top_down_justified(egui::Align::Center), |ui| {
                if ui.button("-->").clicked() {
                    self.update = true;
                    self.page = self.page + 1;
                }
            });
                ui.end_row();


                });
        });
    }
}


fn main() -> eframe::Result<()> {
    eframe::run_native(
        "Swager software",
        eframe::NativeOptions::default(),
        Box::new(|cc| Box::new(WindowApp::new(cc))),
    )
}